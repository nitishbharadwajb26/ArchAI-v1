"""
ArchAI-Enterprise — FastAPI Application
─────────────────────────────────────────
All REST endpoints for the unified architectural advisory +
organisational talent matching + NeetoCal scheduling system.

Endpoints:
  POST /api/recommend          — Full pipeline: recommendation + employee match
  POST /api/schedule           — Create a NeetoCal booking
  POST /api/org/employees      — Seed / upsert employee profiles (admin)
  GET  /api/org/match          — Standalone employee semantic search
  PATCH /api/org/employees/{id}/availability — Toggle availability
  GET  /api/techs              — List all registered tech stacks
  GET  /api/health             — System health check
  GET  /                       — Landing page

Run:
  uvicorn api:app --reload --port 8000
"""

import logging
import sys
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, EmailStr, Field

# ── path bootstrap ────────────────────────────────────────────────────────────
_ROOT   = Path(__file__).resolve().parent
_SCRAPER = _ROOT / "scraper"
_RAG    = _ROOT / "rag"
for p in [str(_ROOT), str(_SCRAPER), str(_RAG), str(_RAG / "tech_agents")]:
    if p not in sys.path:
        sys.path.insert(0, p)

from config.tech_registry import TECH_REGISTRY
from config.provider_config import get_config
from rag.retriever import Retriever
from org.employee_store import EmployeeStore, EmployeeProfile, Manager
from org.seed_data import DEFAULT_EMPLOYEES
from langgraph_supervisor import LangGraphSupervisor
from scheduler.neeto_booking import validate_api_key

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)

# ── singletons ────────────────────────────────────────────────────────────────
supervisor: Optional[LangGraphSupervisor] = None
emp_store:  Optional[EmployeeStore] = None
retriever:  Optional[Retriever] = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global supervisor, emp_store, retriever
    cfg = get_config()
    logger.info("\n" + cfg.summary())

    retriever  = Retriever()
    emp_store  = EmployeeStore()
    supervisor = LangGraphSupervisor(retriever=retriever, emp_store=emp_store)

    # Auto-seed employees if collection is empty
    if emp_store.count() == 0:
        logger.info("Employee store empty — seeding default profiles...")
        emp_store.upsert(DEFAULT_EMPLOYEES)
        logger.info(f"Seeded {len(DEFAULT_EMPLOYEES)} employee profiles ✓")

    logger.info("ArchAI-Enterprise ready ✓")
    yield
    logger.info("Shutting down")


app = FastAPI(
    title="ArchAI-Enterprise",
    description=(
        "Documentation-grounded multi-agent RAG for software architecture recommendation, "
        "organisational talent discovery, and automated consultation scheduling."
    ),
    version="2.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ════════════════════════════════════════════════════════════════════════════════
#  REQUEST / RESPONSE MODELS
# ════════════════════════════════════════════════════════════════════════════════

class RecommendRequest(BaseModel):
    query:       str = Field(..., min_length=3, max_length=2000,
                             description="Free-text project requirement")
    tech_filter: Optional[list[str]] = Field(None,
                             description="Optional: restrict routing to these tech IDs")


class ScheduleRequest(BaseModel):
    employee_id:  str = Field(..., description="Employee ID from a matched_employees card")
    client_name:  str = Field(..., min_length=2)
    client_email: str = Field(..., description="Client email address")
    slot_date:    str = Field(..., description="YYYY-MM-DD format")
    slot_time:    str = Field(..., description="e.g. '10:30 AM'")
    timezone:     str = Field("Asia/Kolkata", description="IANA timezone string")
    notes:        str = Field("", description="Optional notes for the meeting")


class EmployeeUpsertRequest(BaseModel):
    employees: list[dict] = Field(..., description="List of employee profile dicts")


class EmployeeMatchRequest(BaseModel):
    query:          str  = Field(..., min_length=3)
    top_k:          int  = Field(3, ge=1, le=10)
    only_available: bool = Field(True)
    min_experience: int  = Field(0, ge=0)


class AvailabilityPatch(BaseModel):
    available: bool


# ════════════════════════════════════════════════════════════════════════════════
#  ENDPOINTS
# ════════════════════════════════════════════════════════════════════════════════

@app.get("/", response_class=HTMLResponse, include_in_schema=False)
async def root():
    return """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>ArchAI-Enterprise</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0}
    body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
         background:#0f172a;color:#e2e8f0;min-height:100vh;
         display:flex;align-items:center;justify-content:center;padding:2rem}
    .card{background:#1e293b;border:1px solid #334155;border-radius:16px;
          padding:2.5rem;max-width:640px;width:100%}
    h1{font-size:1.8rem;font-weight:700;color:#38bdf8;margin-bottom:.4rem}
    p{color:#94a3b8;margin-bottom:1.5rem;line-height:1.6}
    .badge{display:inline-block;background:#0ea5e9;color:#fff;font-size:.7rem;
           font-weight:600;padding:2px 8px;border-radius:999px;margin-left:8px;
           vertical-align:middle}
    .links{display:flex;flex-wrap:wrap;gap:.75rem;margin-bottom:2rem}
    .links a{background:#0f172a;border:1px solid #334155;color:#38bdf8;
             text-decoration:none;padding:.5rem 1rem;border-radius:8px;
             font-size:.875rem;transition:background .2s}
    .links a:hover{background:#1e3a5f}
    pre{background:#0f172a;border:1px solid #334155;border-radius:8px;
        padding:1rem;font-size:.78rem;overflow-x:auto;color:#7dd3fc;line-height:1.7}
    .section{margin-bottom:1.5rem}
    h3{font-size:.95rem;font-weight:600;color:#cbd5e1;margin-bottom:.6rem}
  </style>
</head>
<body>
<div class="card">
  <h1>ArchAI-Enterprise <span class="badge">v2.0</span></h1>
  <p>Documentation-grounded multi-agent RAG · Organisational talent intelligence · NeetoCal scheduling</p>

  <div class="links">
    <a href="/docs">📖 API Docs</a>
    <a href="/api/health">💚 Health</a>
    <a href="/api/techs">📚 Tech Stacks</a>
    <a href="/api/org/match?query=fastapi+backend&top_k=3">🔍 Employee Search</a>
  </div>

  <div class="section">
    <h3>Architecture recommendation</h3>
    <pre>curl -X POST http://localhost:8000/api/recommend \\
  -H "Content-Type: application/json" \\
  -d '{"query": "I need a scalable Python REST API with async support"}'</pre>
  </div>

  <div class="section">
    <h3>Schedule a consultation</h3>
    <pre>curl -X POST http://localhost:8000/api/schedule \\
  -H "Content-Type: application/json" \\
  -d '{
    "employee_id": "emp_001",
    "client_name": "Jane Doe",
    "client_email": "jane@example.com",
    "slot_date": "2025-07-15",
    "slot_time": "10:30 AM"
  }'</pre>
  </div>
</div>
</body>
</html>"""


# ── Recommendation ─────────────────────────────────────────────────────────────

@app.post("/api/recommend")
async def recommend(request: RecommendRequest):
    """
    Full pipeline: routes query → runs specialist tech agents →
    synthesises recommendation → auto-matches internal experts.
    """
    if supervisor is None:
        raise HTTPException(503, "Supervisor not initialised")

    try:
        result = supervisor.run(request.query)
        return result
    except Exception as e:
        logger.exception("Recommend failed")
        raise HTTPException(500, f"Pipeline error: {e}")


# ── Scheduling ─────────────────────────────────────────────────────────────────

@app.post("/api/schedule")
async def schedule_consultation(request: ScheduleRequest):
    """
    Create a NeetoCal booking on the matched employee's manager scheduling link.
    Returns booking SID and confirmation URL on success.
    """
    if supervisor is None:
        raise HTTPException(503, "Supervisor not initialised")

    try:
        result = supervisor.book(
            employee_id=request.employee_id,
            client_name=request.client_name,
            client_email=request.client_email,
            slot_date=request.slot_date,
            slot_time=request.slot_time,
            timezone=request.timezone,
        )
        if not result.get("success"):
            raise HTTPException(422, detail=result.get("message", "Booking failed"))
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Schedule failed")
        raise HTTPException(500, f"Scheduling error: {e}")


# ── Employee management ────────────────────────────────────────────────────────

@app.post("/api/org/employees", status_code=status.HTTP_201_CREATED)
async def upsert_employees(request: EmployeeUpsertRequest):
    """
    Admin endpoint: seed or update employee profiles.
    Accepts a list of employee dicts matching the EmployeeProfile schema.
    """
    if emp_store is None:
        raise HTTPException(503, "Employee store not initialised")

    profiles = []
    errors   = []
    for i, raw in enumerate(request.employees):
        try:
            profiles.append(EmployeeProfile.from_dict(raw))
        except Exception as e:
            errors.append({"index": i, "error": str(e)})

    if errors:
        raise HTTPException(422, detail={"validation_errors": errors})

    count = emp_store.upsert(profiles)
    return {"upserted": count, "total_in_store": emp_store.count()}


@app.get("/api/org/match")
async def match_employees(
    query:          str  = "software architect",
    top_k:          int  = 3,
    only_available: bool = True,
    min_experience: int  = 0,
):
    """
    Semantic employee search. Returns top-k matched employees for a free-text query.
    """
    if emp_store is None:
        raise HTTPException(503, "Employee store not initialised")

    results = emp_store.search(
        query=query,
        top_k=top_k,
        only_available=only_available,
        min_experience=min_experience,
    )
    return {
        "query":   query,
        "results": results,
        "count":   len(results),
        "total_employees_in_store": emp_store.count(),
    }


@app.patch("/api/org/employees/{employee_id}/availability")
async def toggle_availability(employee_id: str, patch: AvailabilityPatch):
    """Toggle an employee's availability flag (admin use)."""
    if emp_store is None:
        raise HTTPException(503, "Employee store not initialised")

    success = emp_store.update_availability(employee_id, patch.available)
    if not success:
        raise HTTPException(404, f"Employee '{employee_id}' not found")
    return {"employee_id": employee_id, "availability": patch.available}


# ── Tech stacks ────────────────────────────────────────────────────────────────

@app.get("/api/techs")
async def list_techs():
    """List all registered technology stacks with their status."""
    if retriever is None:
        raise HTTPException(503, "Retriever not initialised")

    stats     = retriever.get_available_techs()
    stats_map = {s["tech_id"]: s for s in stats}
    result    = []

    for tech_id, tech in TECH_REGISTRY.items():
        stat = stats_map.get(tech_id, {})
        result.append({
            "id":          tech_id,
            "name":        tech.name,
            "language":    tech.language,
            "category":    tech.category,
            "tags":        tech.tags,
            "status":      stat.get("status", "empty"),
        })

    return {"techs": result, "total": len(result)}


# ── Health ─────────────────────────────────────────────────────────────────────

@app.get("/api/health")
async def health():
    """System health check: ChromaDB, LLM provider, NeetoCal API key."""
    from config.provider_config import LLMProvider
    cfg    = get_config()
    status = "ok"
    result: dict = {
        "status": status,
        "config": {
            "router_model":      cfg.router_model,
            "router_provider":   cfg.router_provider.value,
            "agent_model":       cfg.agent_model,
            "agent_provider":    cfg.agent_provider.value,
            "embedding_model":   cfg.embedding_model,
        },
    }

    # ChromaDB
    if retriever is not None:
        try:
            tech_stats = retriever.get_available_techs()
            result["chromadb"] = {
                "populated_collections": len(tech_stats),
                "techs": [s["tech_id"] for s in tech_stats],
            }
        except Exception as e:
            result["chromadb"] = {"error": str(e)}
            status = "degraded"
    else:
        result["chromadb"] = {"error": "retriever not initialised"}
        status = "degraded"

    # Employee store
    if emp_store is not None:
        result["employee_store"] = {
            "total_employees": emp_store.count(),
            "status":          "ok" if emp_store.count() > 0 else "empty",
        }

    # LLM provider
    if cfg.agent_provider == LLMProvider.GROQ:
        result["llm"] = {"provider": "groq", "api_key_set": bool(cfg.groq_api_key)}
        if not cfg.groq_api_key:
            status = "degraded"

    # NeetoCal
    result["neetocal"] = {"api_key_configured": validate_api_key()}

    result["status"] = status
    return result
