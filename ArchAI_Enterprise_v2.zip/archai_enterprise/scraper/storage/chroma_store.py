"""
ChromaDB Storage Layer
───────────────────────
Thin wrapper around ChromaDB client used by both the documentation
retriever and the organisational employee store.

Collection naming convention:
  - Tech docs  : architectai_docs_{tech_id}   e.g. architectai_docs_fastapi
  - Employees  : archai_employees
"""

import logging
from pathlib import Path
from typing import Optional

import chromadb
from chromadb.config import Settings

logger = logging.getLogger(__name__)


class ChromaStorage:
    """Persistent ChromaDB client with helpers for querying and stats."""

    COLLECTION_PREFIX = "architectai_docs_"

    def __init__(self, persist_dir: str = "./data/chromadb"):
        Path(persist_dir).mkdir(parents=True, exist_ok=True)
        self.client = chromadb.PersistentClient(
            path=persist_dir,
            settings=Settings(anonymized_telemetry=False),
        )
        logger.info(f"ChromaStorage initialised | persist_dir={persist_dir}")

    # ── collection helpers ────────────────────────────────────────────────────

    def _collection_name(self, tech_id: str) -> str:
        return f"{self.COLLECTION_PREFIX}{tech_id}"

    def get_or_create_collection(self, name: str):
        return self.client.get_or_create_collection(
            name=name,
            metadata={"hnsw:space": "cosine"},
        )

    def get_collection(self, tech_id: str):
        name = self._collection_name(tech_id)
        try:
            return self.client.get_collection(name)
        except Exception:
            return None

    # ── query ─────────────────────────────────────────────────────────────────

    def query(
        self,
        tech_ids: list[str],
        query_text: str,
        n_results: int = 5,
        filter_has_code: Optional[bool] = None,
    ) -> list[dict]:
        """
        Query one or more tech collections and return merged results.

        Args:
            tech_ids       : list of tech identifiers e.g. ['fastapi', 'react']
            query_text     : natural-language query string
            n_results      : number of results per collection
            filter_has_code: if True restrict to chunks with code; None = no filter

        Returns:
            List of result dicts with keys: content, metadata, relevance_score
        """
        all_results: list[dict] = []

        where = {"has_code": True} if filter_has_code else None

        for tech_id in tech_ids:
            collection = self.get_collection(tech_id)
            if collection is None:
                logger.warning(f"Collection not found for tech_id={tech_id}")
                continue

            try:
                kwargs: dict = dict(
                    query_texts=[query_text],
                    n_results=min(n_results, collection.count()),
                    include=["documents", "metadatas", "distances"],
                )
                if where:
                    kwargs["where"] = where

                res = collection.query(**kwargs)

                docs      = res["documents"][0]
                metas     = res["metadatas"][0]
                distances = res["distances"][0]

                for doc, meta, dist in zip(docs, metas, distances):
                    all_results.append({
                        "content":        doc,
                        "metadata":       meta,
                        "relevance_score": round(1 - dist, 4),
                    })

            except Exception as e:
                logger.error(f"Query failed for tech_id={tech_id}: {e}")

        # sort merged results by relevance descending
        all_results.sort(key=lambda r: r["relevance_score"], reverse=True)
        return all_results

    def query_collection(
        self,
        collection_name: str,
        query_text: str,
        n_results: int = 5,
        where: Optional[dict] = None,
    ) -> list[dict]:
        """Generic query against any named collection (used by employee store)."""
        try:
            col = self.client.get_collection(collection_name)
        except Exception:
            logger.warning(f"Collection '{collection_name}' not found")
            return []

        count = col.count()
        if count == 0:
            return []

        kwargs: dict = dict(
            query_texts=[query_text],
            n_results=min(n_results, count),
            include=["documents", "metadatas", "distances"],
        )
        if where:
            kwargs["where"] = where

        try:
            res = col.query(**kwargs)
            results = []
            for doc, meta, dist in zip(
                res["documents"][0],
                res["metadatas"][0],
                res["distances"][0],
            ):
                results.append({
                    "content":        doc,
                    "metadata":       meta,
                    "relevance_score": round(1 - dist, 4),
                })
            return results
        except Exception as e:
            logger.error(f"query_collection failed: {e}")
            return []

    # ── upsert ────────────────────────────────────────────────────────────────

    def upsert(
        self,
        collection_name: str,
        ids: list[str],
        documents: list[str],
        metadatas: list[dict],
        embeddings: Optional[list[list[float]]] = None,
    ) -> None:
        """Upsert documents into any named collection."""
        col = self.get_or_create_collection(collection_name)
        kwargs: dict = dict(ids=ids, documents=documents, metadatas=metadatas)
        if embeddings:
            kwargs["embeddings"] = embeddings
        col.upsert(**kwargs)
        logger.info(f"Upserted {len(ids)} docs into '{collection_name}'")

    def delete(self, collection_name: str, ids: list[str]) -> None:
        try:
            col = self.client.get_collection(collection_name)
            col.delete(ids=ids)
        except Exception as e:
            logger.warning(f"Delete failed for '{collection_name}': {e}")

    # ── stats ─────────────────────────────────────────────────────────────────

    def get_all_stats(self) -> list[dict]:
        """Return stats for all tech-doc collections that have data."""
        stats = []
        for col in self.client.list_collections():
            if not col.name.startswith(self.COLLECTION_PREFIX):
                continue
            tech_id    = col.name[len(self.COLLECTION_PREFIX):]
            chunk_count = col.count()
            if chunk_count > 0:
                stats.append({
                    "tech_id":     tech_id,
                    "collection":  col.name,
                    "chunk_count": chunk_count,
                    "status":      "populated",
                })
        return stats

    def get_collection_stats(self, tech_id: str) -> dict:
        collection = self.get_collection(tech_id)
        if collection is None:
            return {"tech_id": tech_id, "chunk_count": 0, "status": "empty"}
        count = collection.count()
        return {
            "tech_id":     tech_id,
            "collection":  self._collection_name(tech_id),
            "chunk_count": count,
            "status":      "populated" if count > 0 else "empty",
        }

    def collection_count(self, collection_name: str) -> int:
        try:
            return self.client.get_collection(collection_name).count()
        except Exception:
            return 0
