"""
NeetoCal Booking Agent
────────────────────────
Handles scheduling consultation calls via the NeetoCal REST API.

NeetoCal API docs: https://apidocs.neetocal.com
Each manager stores their workspace subdomain + scheduling link slug.
The booking endpoint: POST https://{workspace}.neetocal.com/api/external/v1/bookings
"""

import logging
import os
from dataclasses import dataclass
from typing import Optional
from urllib.parse import urlparse

import httpx

logger = logging.getLogger(__name__)

NEETO_API_KEY = os.getenv("NEETOCAL_API_KEY", "")
DEFAULT_TIMEZONE = "Asia/Kolkata"


@dataclass
class BookingRequest:
    client_name:   str
    client_email:  str
    slot_date:     str          # YYYY-MM-DD
    slot_time:     str          # e.g. "10:30 AM"
    timezone:      str = DEFAULT_TIMEZONE
    notes:         str = ""


@dataclass
class BookingResult:
    success:          bool
    booking_sid:      Optional[str] = None
    confirmation_url: Optional[str] = None
    message:          str = ""
    error:            Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "success":          self.success,
            "booking_sid":      self.booking_sid,
            "confirmation_url": self.confirmation_url,
            "message":          self.message,
            "error":            self.error,
        }


def _parse_workspace_and_slug(neeto_link: str) -> tuple[str, str]:
    """
    Extract workspace subdomain and scheduling slug from a NeetoCal URL.
    e.g. https://archai.neetocal.com/priya-sharma  →  ('archai', 'priya-sharma')
    """
    parsed = urlparse(neeto_link)
    # host: archai.neetocal.com
    workspace = parsed.hostname.split(".")[0] if parsed.hostname else ""
    # path: /priya-sharma
    slug = parsed.path.strip("/")
    return workspace, slug


def book_consultation(
    neeto_scheduling_link: str,
    request: BookingRequest,
    api_key: Optional[str] = None,
) -> BookingResult:
    """
    Create a booking on a manager's NeetoCal scheduling link.

    Args:
        neeto_scheduling_link : Full NeetoCal URL from the employee record
        request               : BookingRequest with client and slot details
        api_key               : NeetoCal API key (falls back to NEETOCAL_API_KEY env var)

    Returns:
        BookingResult with success flag, SID, and confirmation URL
    """
    key = api_key or NEETO_API_KEY

    if not key:
        logger.error("NEETOCAL_API_KEY not set — cannot create booking")
        return BookingResult(
            success=False,
            error="NEETOCAL_API_KEY environment variable is not set. "
                  "Add it to your .env file to enable scheduling.",
            message="Scheduling is not configured. Please contact the team directly.",
        )

    if not neeto_scheduling_link:
        return BookingResult(
            success=False,
            error="No NeetoCal scheduling link available for this manager.",
            message="Direct scheduling is unavailable for this contact.",
        )

    workspace, slug = _parse_workspace_and_slug(neeto_scheduling_link)
    if not workspace or not slug:
        return BookingResult(
            success=False,
            error=f"Could not parse NeetoCal link: {neeto_scheduling_link}",
            message="Invalid scheduling link format.",
        )

    url = f"https://{workspace}.neetocal.com/api/external/v1/bookings"

    payload = {
        "name":             request.client_name,
        "email":            request.client_email,
        "time_zone":        request.timezone,
        "slot_date":        request.slot_date,
        "slot_start_time":  request.slot_time,
        "scheduling_link_slug": slug,
    }
    if request.notes:
        payload["form_responses"] = {"notes": request.notes}

    headers = {
        "X-Api-Key":    key,
        "Content-Type": "application/json",
        "Accept":       "application/json",
    }

    try:
        with httpx.Client(timeout=15.0) as client:
            resp = client.post(url, json=payload, headers=headers)

        if resp.status_code in (200, 201):
            data = resp.json()
            sid  = data.get("booking", {}).get("sid") or data.get("sid")
            conf = data.get("booking", {}).get("confirmation_url") or neeto_scheduling_link
            logger.info(f"Booking created successfully | sid={sid}")
            return BookingResult(
                success=True,
                booking_sid=sid,
                confirmation_url=conf,
                message=(
                    f"Your consultation call has been scheduled! "
                    f"A calendar invitation will be sent to {request.client_email}. "
                    f"Booking reference: {sid}"
                ),
            )

        elif resp.status_code == 422:
            detail = resp.json().get("error", resp.text)
            logger.warning(f"NeetoCal validation error: {detail}")
            return BookingResult(
                success=False,
                error=detail,
                message="The requested slot is unavailable. Please choose another time.",
            )

        else:
            logger.error(f"NeetoCal API error {resp.status_code}: {resp.text[:200]}")
            return BookingResult(
                success=False,
                error=f"API returned {resp.status_code}",
                message="Booking service encountered an error. Please try again later.",
            )

    except httpx.TimeoutException:
        return BookingResult(
            success=False,
            error="Request timed out",
            message="NeetoCal booking service timed out. Please try again.",
        )
    except Exception as e:
        logger.exception("Unexpected error during booking")
        return BookingResult(
            success=False,
            error=str(e),
            message="An unexpected error occurred during scheduling.",
        )


def validate_api_key(api_key: Optional[str] = None) -> bool:
    """Quick health check — verify the NeetoCal API key is set and non-empty."""
    key = api_key or NEETO_API_KEY
    return bool(key and len(key) > 10)
