"""
Organisational Employee Store
──────────────────────────────
Manages the employee knowledge base in ChromaDB.
Provides:
  - Seeding / upserting employee profiles
  - Semantic search with availability filtering
  - CRUD helpers for individual records

Collection: archai_employees
"""

import json
import logging
import sys
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional

# ── path bootstrap ────────────────────────────────────────────────────────────
_ROOT = Path(__file__).resolve().parent.parent
_SCRAPER = _ROOT / "scraper"
for p in [str(_ROOT), str(_SCRAPER)]:
    if p not in sys.path:
        sys.path.insert(0, p)

from storage.chroma_store import ChromaStorage
from config.provider_config import get_config

logger = logging.getLogger(__name__)

EMPLOYEE_COLLECTION = "archai_employees"


# ── Data models ───────────────────────────────────────────────────────────────

@dataclass
class Manager:
    name:               str
    email:              str
    neeto_scheduling_link: str   # full URL to NeetoCal scheduling page


@dataclass
class EmployeeProfile:
    id:                 str
    name:               str
    role:               str
    department:         str
    tech_stack:         list[str]
    domains:            list[str]        # e.g. ["cloud", "backend", "ml"]
    experience_years:   int
    availability:       bool
    manager:            Manager

    def to_narrative(self) -> str:
        """Natural-language text used as the embedding document."""
        avail = "Currently available for engagements." if self.availability else "Not currently available."
        return (
            f"{self.name} is a {self.role} in the {self.department} department "
            f"with {self.experience_years} years of experience. "
            f"Technology stack: {', '.join(self.tech_stack)}. "
            f"Domain expertise: {', '.join(self.domains)}. "
            f"{avail}"
        )

    def to_chroma_metadata(self) -> dict:
        """Flat metadata dict stored alongside the embedding."""
        return {
            "id":               self.id,
            "name":             self.name,
            "role":             self.role,
            "department":       self.department,
            "tech_stack":       json.dumps(self.tech_stack),
            "domains":          json.dumps(self.domains),
            "experience_years": self.experience_years,
            "availability":     self.availability,
            "manager_name":     self.manager.name,
            "manager_email":    self.manager.email,
            "neeto_link":       self.manager.neeto_scheduling_link,
        }

    def to_card(self, score: float = 0.0) -> dict:
        """Public-facing employee card (shown to external clients)."""
        return {
            "id":               self.id,
            "name":             self.name,
            "role":             self.role,
            "department":       self.department,
            "tech_stack":       self.tech_stack,
            "domains":          self.domains,
            "experience_years": self.experience_years,
            "availability":     self.availability,
            "match_score":      round(score, 3),
            "manager":          {
                "name":              self.manager.name,
                "neeto_booking_url": self.manager.neeto_scheduling_link,
            },
        }

    @classmethod
    def from_dict(cls, data: dict) -> "EmployeeProfile":
        mgr = Manager(**data["manager"])
        return cls(
            id=data["id"],
            name=data["name"],
            role=data["role"],
            department=data["department"],
            tech_stack=data["tech_stack"],
            domains=data["domains"],
            experience_years=data["experience_years"],
            availability=data["availability"],
            manager=mgr,
        )

    @classmethod
    def from_chroma_metadata(cls, meta: dict) -> "EmployeeProfile":
        return cls(
            id=meta["id"],
            name=meta["name"],
            role=meta["role"],
            department=meta["department"],
            tech_stack=json.loads(meta.get("tech_stack", "[]")),
            domains=json.loads(meta.get("domains", "[]")),
            experience_years=int(meta.get("experience_years", 0)),
            availability=bool(meta.get("availability", False)),
            manager=Manager(
                name=meta.get("manager_name", ""),
                email=meta.get("manager_email", ""),
                neeto_scheduling_link=meta.get("neeto_link", ""),
            ),
        )


# ── Store ─────────────────────────────────────────────────────────────────────

class EmployeeStore:
    """ChromaDB-backed semantic employee knowledge base."""

    def __init__(self, chroma_path: Optional[str] = None):
        if chroma_path is None:
            chroma_path = str(_ROOT / "data" / "chromadb")
        self.storage = ChromaStorage(persist_dir=chroma_path)
        self._embedding_fn = self._get_embedding_fn()
        logger.info("EmployeeStore initialised")

    # ── embedding ─────────────────────────────────────────────────────────────

    def _get_embedding_fn(self):
        """Return callable that embeds a list of strings → list[list[float]]."""
        cfg = get_config()
        try:
            import requests
            r = requests.get(f"{cfg.ollama_base_url}/api/tags", timeout=3)
            if r.status_code == 200:
                logger.info("Using Ollama nomic-embed-text for employee embeddings")
                def embed_ollama(texts: list[str]) -> list[list[float]]:
                    out = []
                    for t in texts:
                        resp = requests.post(
                            f"{cfg.ollama_base_url}/api/embeddings",
                            json={"model": cfg.embedding_model, "prompt": t},
                            timeout=30,
                        )
                        resp.raise_for_status()
                        out.append(resp.json()["embedding"])
                    return out
                return embed_ollama
        except Exception:
            pass

        logger.info("Ollama unavailable — using sentence-transformers for employee embeddings")
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer(cfg.embedding_fallback_model)

        def embed_st(texts: list[str]) -> list[list[float]]:
            return model.encode(texts, convert_to_numpy=True).tolist()

        return embed_st

    # ── write ─────────────────────────────────────────────────────────────────

    def upsert(self, profiles: list[EmployeeProfile]) -> int:
        """Upsert a batch of employee profiles. Returns count upserted."""
        if not profiles:
            return 0

        narratives = [p.to_narrative() for p in profiles]
        embeddings = self._embedding_fn(narratives)
        ids        = [p.id for p in profiles]
        metadatas  = [p.to_chroma_metadata() for p in profiles]

        self.storage.upsert(
            collection_name=EMPLOYEE_COLLECTION,
            ids=ids,
            documents=narratives,
            metadatas=metadatas,
            embeddings=embeddings,
        )
        logger.info(f"Upserted {len(profiles)} employee profiles")
        return len(profiles)

    def delete(self, employee_id: str) -> None:
        self.storage.delete(EMPLOYEE_COLLECTION, [employee_id])

    def update_availability(self, employee_id: str, available: bool) -> bool:
        """Toggle availability flag by re-embedding the profile."""
        profile = self.get_by_id(employee_id)
        if profile is None:
            return False
        profile.availability = available
        self.upsert([profile])
        return True

    # ── read ──────────────────────────────────────────────────────────────────

    def get_by_id(self, employee_id: str) -> Optional[EmployeeProfile]:
        try:
            col = self.storage.client.get_collection(EMPLOYEE_COLLECTION)
            res = col.get(ids=[employee_id], include=["metadatas"])
            if res["metadatas"]:
                return EmployeeProfile.from_chroma_metadata(res["metadatas"][0])
        except Exception as e:
            logger.error(f"get_by_id failed: {e}")
        return None

    def count(self) -> int:
        return self.storage.collection_count(EMPLOYEE_COLLECTION)

    # ── semantic search ───────────────────────────────────────────────────────

    def search(
        self,
        query: str,
        top_k: int = 3,
        only_available: bool = True,
        min_experience: int = 0,
    ) -> list[dict]:
        """
        Semantic search over employee profiles.

        Args:
            query          : free-text semantic query
            top_k          : number of candidates to return
            only_available : if True, filter to availability = True
            min_experience : minimum years of experience required

        Returns:
            List of employee card dicts with match_score
        """
        # Retrieve more than top_k so post-filters don't exhaust results
        fetch_k = min(top_k * 4, max(self.count(), 1))
        results = self.storage.query_collection(
            collection_name=EMPLOYEE_COLLECTION,
            query_text=query,
            n_results=fetch_k,
        )

        cards = []
        for r in results:
            meta  = r["metadata"]
            score = r["relevance_score"]
            try:
                profile = EmployeeProfile.from_chroma_metadata(meta)
            except Exception:
                continue

            if only_available and not profile.availability:
                continue
            if profile.experience_years < min_experience:
                continue

            cards.append(profile.to_card(score=score))
            if len(cards) >= top_k:
                break

        logger.info(f"Employee search | query='{query[:60]}' | returned={len(cards)}")
        return cards

    def match_for_recommendation(
        self,
        recommended_techs: list[str],
        domains: list[str],
        top_k: int = 3,
    ) -> list[dict]:
        """
        Build a composite query from recommended tech stack + domains
        and run semantic search. Called automatically after synthesis.
        """
        query_parts = []
        if recommended_techs:
            query_parts.append(f"Expert in {', '.join(recommended_techs)}")
        if domains:
            query_parts.append(f"Domain: {', '.join(domains)}")
        query = ". ".join(query_parts) if query_parts else "Software architect available for consultation"
        return self.search(query, top_k=top_k, only_available=True)
