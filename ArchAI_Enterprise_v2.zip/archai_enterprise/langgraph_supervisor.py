"""
LangGraph Supervisor
──────────────────────
Replaces the old RAGChain + AgentOrchestrator with an explicit
LangGraph StateGraph.

Graph topology:
  supervisor → router → tech_agents (parallel) → synthesiser
             → employee_matcher (auto)
             → [conditional] booking_agent
             → response

Shared state (AgentState) flows through every node.
"""

import json
import logging
import re
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Annotated, Any, Optional, TypedDict

# ── path bootstrap ────────────────────────────────────────────────────────────
_ROOT   = Path(__file__).resolve().parent
_SCRAPER = _ROOT / "scraper"
_RAG    = _ROOT / "rag"
for p in [str(_ROOT), str(_SCRAPER), str(_RAG), str(_RAG / "tech_agents")]:
    if p not in sys.path:
        sys.path.insert(0, p)

from langgraph.graph import StateGraph, END

from config.tech_registry import TECH_REGISTRY
from config.provider_config import get_config, LLMProvider
from rag.retriever import Retriever
from rag.router import Router
from rag.agents import AgentOrchestrator
from rag.prompts import CHAIN_SYSTEM, CHAIN_USER, FALLBACK_SYSTEM, FALLBACK_USER
from rag.tech_agents.base_agent import AgentResult
from org.employee_store import EmployeeStore

logger = logging.getLogger(__name__)


# ── shared state ──────────────────────────────────────────────────────────────

class AgentState(TypedDict):
    # inputs
    query:              str
    # routing
    routed_techs:       list[str]
    # agent outputs
    agent_results:      list[dict]          # AgentResult.to_dict()
    # synthesis
    synthesis:          dict                # structured recommendation
    # employee layer
    matched_employees:  list[dict]          # employee cards
    # booking (optional — only set when user requests it)
    booking_requested:  bool
    booking_employee_id: Optional[str]
    booking_client_name: Optional[str]
    booking_client_email: Optional[str]
    booking_slot_date:  Optional[str]
    booking_slot_time:  Optional[str]
    booking_timezone:   Optional[str]
    booking_result:     Optional[dict]
    # final
    error:              Optional[str]


# ── node implementations ──────────────────────────────────────────────────────

def _llm_call(system: str, user: str, max_tokens: int = 2000) -> str:
    """Provider-agnostic LLM call used by synthesiser."""
    cfg = get_config()
    if cfg.agent_provider == LLMProvider.GROQ:
        from groq import Groq
        client = Groq(api_key=cfg.groq_api_key)
        resp = client.chat.completions.create(
            model=cfg.agent_model.replace("groq/", ""),
            messages=[
                {"role": "system", "content": system},
                {"role": "user",   "content": user},
            ],
            temperature=0.4,
            max_tokens=max_tokens,
            timeout=cfg.synthesis_timeout,
        )
        return resp.choices[0].message.content

    elif cfg.agent_provider == LLMProvider.OLLAMA:
        import requests
        resp = requests.post(
            f"{cfg.ollama_base_url}/api/chat",
            json={
                "model": cfg.agent_model,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user",   "content": user},
                ],
                "stream": False,
                "options": {"temperature": 0.4},
            },
            timeout=cfg.synthesis_timeout,
        )
        resp.raise_for_status()
        return resp.json()["message"]["content"]

    elif cfg.agent_provider == LLMProvider.OPENAI:
        from openai import OpenAI
        client = OpenAI(api_key=cfg.openai_api_key)
        resp = client.chat.completions.create(
            model=cfg.agent_model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user",   "content": user},
            ],
            temperature=0.4,
            max_tokens=max_tokens,
        )
        return resp.choices[0].message.content

    raise ValueError(f"Unknown provider: {cfg.agent_provider}")


def _parse_json(raw: str) -> dict:
    clean = re.sub(r"```(?:json)?", "", raw).strip("` \n")
    match = re.search(r"\{.*\}", clean, re.DOTALL)
    if not match:
        raise ValueError(f"No JSON object found in: {raw[:200]}")
    return json.loads(match.group())


# ── Graph nodes ────────────────────────────────────────────────────────────────

def node_router(state: AgentState, router: Router) -> dict:
    """Route the query to relevant tech IDs."""
    logger.info(f"[Router] query='{state['query'][:80]}'")
    tech_ids = router.route(state["query"])
    logger.info(f"[Router] → {tech_ids}")
    return {"routed_techs": tech_ids}


def node_tech_agents(state: AgentState, orchestrator: AgentOrchestrator) -> dict:
    """Run all specialist tech agents in parallel."""
    tech_ids = state["routed_techs"]
    if not tech_ids:
        return {"agent_results": []}
    results: list[AgentResult] = orchestrator.run(tech_ids, state["query"])
    return {"agent_results": [r.to_dict() for r in results]}


def node_synthesiser(state: AgentState) -> dict:
    """Synthesise all agent outputs into a unified architectural recommendation."""
    agent_results = state["agent_results"]
    query         = state["query"]

    if not agent_results:
        # fallback with no RAG context
        try:
            raw = _llm_call(FALLBACK_SYSTEM, FALLBACK_USER.format(user_query=query))
            return {
                "synthesis": {
                    "summary":               raw.strip(),
                    "recommended_stack":     {},
                    "architecture_overview": "",
                    "implementation_roadmap": [],
                    "key_code_examples":     [],
                    "alternative_consideration": "",
                    "sources":               [],
                },
                "error": "No documentation context found — answered from general knowledge.",
            }
        except Exception as e:
            return {"synthesis": {}, "error": str(e)}

    try:
        raw = _llm_call(
            system=CHAIN_SYSTEM,
            user=CHAIN_USER.format(
                user_query=query,
                agent_outputs=json.dumps(agent_results, indent=2),
            ),
        )
        synthesis = _parse_json(raw)

        # Collect all source URLs across agents
        all_sources: list[str] = []
        for r in agent_results:
            all_sources.extend(r.get("sources", []))
        synthesis["sources"] = list(dict.fromkeys(all_sources))[:10]

        return {"synthesis": synthesis}

    except Exception as e:
        logger.error(f"Synthesiser failed: {e}")
        return {"synthesis": {}, "error": f"Synthesis error: {e}"}


def node_employee_matcher(state: AgentState, emp_store: EmployeeStore) -> dict:
    """Automatically match internal experts to the recommendation."""
    synthesis = state.get("synthesis", {})

    # Extract tech IDs and domain from synthesis
    recommended_stack = synthesis.get("recommended_stack", {})
    techs: list[str] = []
    if recommended_stack.get("backend"):
        techs.append(recommended_stack["backend"])
    if recommended_stack.get("frontend"):
        techs.append(recommended_stack["frontend"])
    techs.extend(recommended_stack.get("additional", []))
    techs = techs or state.get("routed_techs", [])

    # Infer domain from architecture overview text
    overview = synthesis.get("architecture_overview", "").lower()
    domains: list[str] = []
    for kw in ["cloud", "ml", "machine learning", "backend", "frontend",
               "microservices", "api", "fullstack", "devops"]:
        if kw in overview:
            domains.append(kw)

    try:
        employees = emp_store.match_for_recommendation(techs, domains, top_k=3)
    except Exception as e:
        logger.error(f"Employee matching failed: {e}")
        employees = []

    logger.info(f"[EmployeeMatcher] matched {len(employees)} employees")
    return {"matched_employees": employees}


def node_booking_agent(state: AgentState, emp_store: EmployeeStore) -> dict:
    """Create a NeetoCal booking if the user requested it."""
    from scheduler.neeto_booking import book_consultation, BookingRequest

    employee_id  = state.get("booking_employee_id")
    client_name  = state.get("booking_client_name")
    client_email = state.get("booking_client_email")
    slot_date    = state.get("booking_slot_date")
    slot_time    = state.get("booking_slot_time")
    timezone     = state.get("booking_timezone", "Asia/Kolkata")

    if not all([employee_id, client_name, client_email, slot_date, slot_time]):
        return {
            "booking_result": {
                "success": False,
                "error":   "Missing booking fields — need employee_id, client_name, client_email, slot_date, slot_time.",
                "message": "Please provide all required booking details.",
            }
        }

    profile = emp_store.get_by_id(employee_id)
    if profile is None:
        return {
            "booking_result": {
                "success": False,
                "error":   f"Employee {employee_id} not found.",
                "message": "Selected employee not found in the system.",
            }
        }

    result = book_consultation(
        neeto_scheduling_link=profile.manager.neeto_scheduling_link,
        request=BookingRequest(
            client_name=client_name,
            client_email=client_email,
            slot_date=slot_date,
            slot_time=slot_time,
            timezone=timezone,
        ),
    )
    logger.info(f"[BookingAgent] success={result.success}")
    return {"booking_result": result.to_dict()}


# ── conditional edge ──────────────────────────────────────────────────────────

def should_book(state: AgentState) -> str:
    return "booking_agent" if state.get("booking_requested") else END


# ── Supervisor class ──────────────────────────────────────────────────────────

class LangGraphSupervisor:
    """
    Builds and runs the LangGraph StateGraph.
    Single entry point for the full ArchAI-Enterprise pipeline.
    """

    def __init__(
        self,
        retriever:   Optional[Retriever] = None,
        emp_store:   Optional[EmployeeStore] = None,
    ):
        self.cfg         = get_config()
        self.retriever   = retriever or Retriever()
        self.emp_store   = emp_store or EmployeeStore()

        populated = [s["tech_id"] for s in self.retriever.get_available_techs()]
        self.router      = Router(available_tech_ids=populated or list(TECH_REGISTRY.keys()))
        self.orchestrator = AgentOrchestrator(retriever=self.retriever)

        self.graph = self._build_graph()
        logger.info("LangGraphSupervisor ready ✓")

    def _build_graph(self):
        g = StateGraph(AgentState)

        # bind dependencies into node callables
        g.add_node("router",           lambda s: node_router(s, self.router))
        g.add_node("tech_agents",      lambda s: node_tech_agents(s, self.orchestrator))
        g.add_node("synthesiser",      node_synthesiser)
        g.add_node("employee_matcher", lambda s: node_employee_matcher(s, self.emp_store))
        g.add_node("booking_agent",    lambda s: node_booking_agent(s, self.emp_store))

        g.set_entry_point("router")
        g.add_edge("router",           "tech_agents")
        g.add_edge("tech_agents",      "synthesiser")
        g.add_edge("synthesiser",      "employee_matcher")
        g.add_conditional_edges("employee_matcher", should_book)
        g.add_edge("booking_agent",    END)

        return g.compile()

    def run(self, query: str) -> dict:
        """Run the full recommendation pipeline."""
        initial: AgentState = {
            "query":             query,
            "routed_techs":      [],
            "agent_results":     [],
            "synthesis":         {},
            "matched_employees": [],
            "booking_requested": False,
            "booking_employee_id": None,
            "booking_client_name": None,
            "booking_client_email": None,
            "booking_slot_date": None,
            "booking_slot_time": None,
            "booking_timezone":  None,
            "booking_result":    None,
            "error":             None,
        }
        final_state = self.graph.invoke(initial)
        return self._format_response(final_state)

    def book(
        self,
        employee_id:  str,
        client_name:  str,
        client_email: str,
        slot_date:    str,
        slot_time:    str,
        timezone:     str = "Asia/Kolkata",
        context_query: str = "",
    ) -> dict:
        """Standalone booking — skips the tech-agent pipeline."""
        initial: AgentState = {
            "query":               context_query or "Booking consultation",
            "routed_techs":        [],
            "agent_results":       [],
            "synthesis":           {},
            "matched_employees":   [],
            "booking_requested":   True,
            "booking_employee_id": employee_id,
            "booking_client_name": client_name,
            "booking_client_email": client_email,
            "booking_slot_date":   slot_date,
            "booking_slot_time":   slot_time,
            "booking_timezone":    timezone,
            "booking_result":      None,
            "error":               None,
        }
        # fast path: only run employee_matcher + booking_agent
        from scheduler.neeto_booking import book_consultation, BookingRequest
        profile = self.emp_store.get_by_id(employee_id)
        if profile is None:
            return {"success": False, "error": f"Employee {employee_id} not found."}

        result = book_consultation(
            neeto_scheduling_link=profile.manager.neeto_scheduling_link,
            request=BookingRequest(
                client_name=client_name,
                client_email=client_email,
                slot_date=slot_date,
                slot_time=slot_time,
                timezone=timezone,
            ),
        )
        return result.to_dict()

    def _format_response(self, state: AgentState) -> dict:
        syn = state.get("synthesis", {})
        # gather sources from agent results too
        all_sources: list[str] = list(syn.get("sources", []))
        for r in state.get("agent_results", []):
            for s in r.get("sources", []):
                if s not in all_sources:
                    all_sources.append(s)

        return {
            "query":              state["query"],
            "routed_techs":       state["routed_techs"],
            "summary":            syn.get("summary", ""),
            "recommended_stack":  syn.get("recommended_stack", {}),
            "architecture_overview": syn.get("architecture_overview", ""),
            "implementation_roadmap": syn.get("implementation_roadmap", []),
            "key_code_examples":  syn.get("key_code_examples", []),
            "alternative_consideration": syn.get("alternative_consideration", ""),
            "sources":            all_sources[:10],
            "matched_employees":  state.get("matched_employees", []),
            "agent_details":      state.get("agent_results", []),
            "booking_result":     state.get("booking_result"),
            "error":              state.get("error"),
        }
