# ArchAI-Enterprise

> Documentation-grounded multi-agent RAG for software architecture recommendation,
> organisational talent discovery, and automated consultation scheduling via NeetoCal.

---

## What it does

When a client types a requirement like _"I need a scalable Python REST API with async support"_, ArchAI-Enterprise:

1. **Routes** the query to the relevant specialist tech agents (FastAPI, Django, etc.)
2. **Retrieves** documentation chunks from per-technology ChromaDB collections
3. **Synthesises** a single ranked architectural recommendation with code examples and source URLs
4. **Auto-matches** internal employees by semantic similarity to the recommended stack
5. **Books** a consultation call with the matched employee's manager via NeetoCal — directly from the chatbot

---

## Project structure

```
archai_enterprise/
├── api.py                        ← FastAPI application (all endpoints)
├── langgraph_supervisor.py       ← LangGraph StateGraph orchestrator
├── seed_employees.py             ← CLI to seed the employee knowledge base
├── requirements.txt
├── .env.example                  ← copy to .env and fill keys
│
├── rag/
│   ├── retriever.py              ← ChromaDB query wrapper
│   ├── router.py                 ← LLM-based tech routing
│   ├── agents.py                 ← ThreadPool agent orchestrator
│   ├── prompts.py                ← all LLM prompt templates
│   └── tech_agents/              ← 11 specialist agents
│       ├── base_agent.py
│       ├── registry.py
│       ├── fastapi_agent.py
│       ├── django_agent.py
│       ├── flask_agent.py
│       ├── nodejs_agent.py
│       ├── nestjs_agent.py
│       ├── loopback_agent.py
│       ├── react_agent.py
│       ├── angular_agent.py
│       ├── dotnet_core_agent.py
│       ├── dotnet_mvc_agent.py
│       └── blazor_agent.py
│
├── org/
│   ├── employee_store.py         ← ChromaDB-backed employee knowledge base
│   └── seed_data.py              ← 10 default employee profiles
│
├── scheduler/
│   └── neeto_booking.py          ← NeetoCal REST API integration
│
├── scraper/
│   ├── config/
│   │   ├── tech_registry.py      ← all 11 tech stack definitions
│   │   └── provider_config.py    ← LLM provider profiles
│   └── storage/
│       └── chroma_store.py       ← ChromaDB storage layer
│
└── data/
    └── chromadb/                 ← persisted vector collections (auto-created)
```

---

## Prerequisites

| Tool | Version | Purpose |
|------|---------|---------|
| Python | 3.11+ | Runtime |
| [Ollama](https://ollama.com) | Latest | Local embeddings (nomic-embed-text) |
| Groq account | Free | LLM inference (router + agents + synthesis) |
| NeetoCal account | Free | Consultation scheduling API |

---

## Step-by-step local setup

### 1. Clone / unzip the project

```bash
cd archai_enterprise
```

### 2. Create and activate a virtual environment

```bash
python -m venv .venv

# macOS / Linux
source .venv/bin/activate

# Windows (PowerShell)
.venv\Scripts\Activate.ps1
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Install and start Ollama (for embeddings)

```bash
# Install Ollama from https://ollama.com/download
# Then pull the embedding model:
ollama pull nomic-embed-text
```

Verify it's running:
```bash
curl http://localhost:11434/api/tags
```

### 5. Configure environment variables

```bash
cp .env.example .env
```

Edit `.env`:

```env
# Required — get free key at https://console.groq.com
GROQ_API_KEY=gsk_xxxxxxxxxxxxxxxxxxxx

# Required for scheduling — get at https://app.neetocal.com → Settings → API Keys
NEETOCAL_API_KEY=your_neetocal_api_key

# Active profile: groq_free | academic_local | production
ARCHITECTAI_PROFILE=groq_free
```

### 6. Copy your existing ChromaDB data

If you already have documentation scraped (the `data/chromadb/` folder from the original project), copy it in:

```bash
cp -r /path/to/original/ArchAI/scraper/data/chromadb ./data/
```

> **No ChromaDB data yet?**  The system will still run — it falls back to general LLM knowledge for recommendations. To scrape documentation, use the original scraper from the ArchAI project.

### 7. Seed the employee knowledge base

This runs automatically on first server start, but you can also run it manually:

```bash
python seed_employees.py
```

To load your own employees from a JSON file:
```bash
python seed_employees.py --custom my_employees.json
```

Employee JSON format:
```json
[
  {
    "id": "emp_001",
    "name": "Arun Kumar",
    "role": "Senior Backend Engineer",
    "department": "Platform Engineering",
    "tech_stack": ["FastAPI", "PostgreSQL", "Docker", "Kubernetes"],
    "domains": ["backend", "cloud", "microservices"],
    "experience_years": 6,
    "availability": true,
    "manager": {
      "name": "Priya Sharma",
      "email": "priya@company.com",
      "neeto_scheduling_link": "https://yourcompany.neetocal.com/priya-sharma"
    }
  }
]
```

### 8. Start the server

```bash
uvicorn api:app --reload --port 8000
```

Open your browser at **http://localhost:8000** — you'll see the landing page with quick links.

---

## Using the API

### Get an architectural recommendation

```bash
curl -X POST http://localhost:8000/api/recommend \
  -H "Content-Type: application/json" \
  -d '{"query": "I need a scalable Python REST API with async support and PostgreSQL"}'
```

**Response includes:**
- `summary` — 2-3 sentence executive summary
- `recommended_stack` — `{ backend, frontend, additional }`
- `architecture_overview` — detailed pattern description
- `implementation_roadmap` — phased task list
- `key_code_examples` — syntax-highlighted snippets with source URLs
- `matched_employees` — top 3 semantically matched internal experts
- `agent_details` — per-tech confidence scores and reasoning

---

### Schedule a consultation call

After getting a recommendation, use the `employee.id` from `matched_employees`:

```bash
curl -X POST http://localhost:8000/api/schedule \
  -H "Content-Type: application/json" \
  -d '{
    "employee_id": "emp_001",
    "client_name": "Jane Doe",
    "client_email": "jane@clientcompany.com",
    "slot_date": "2025-07-15",
    "slot_time": "10:30 AM",
    "timezone": "Asia/Kolkata"
  }'
```

**Response:**
```json
{
  "success": true,
  "booking_sid": "abc123xyz",
  "confirmation_url": "https://archai.neetocal.com/bookings/abc123xyz",
  "message": "Your consultation call has been scheduled! A calendar invitation will be sent to jane@clientcompany.com. Booking reference: abc123xyz"
}
```

---

### Search employees directly

```bash
curl "http://localhost:8000/api/org/match?query=kubernetes+microservices+backend&top_k=3"
```

---

### Upsert employees (admin)

```bash
curl -X POST http://localhost:8000/api/org/employees \
  -H "Content-Type: application/json" \
  -d '{"employees": [{ ...employee dict... }]}'
```

---

### Toggle employee availability

```bash
curl -X PATCH http://localhost:8000/api/org/employees/emp_001/availability \
  -H "Content-Type: application/json" \
  -d '{"available": false}'
```

---

### Health check

```bash
curl http://localhost:8000/api/health
```

Returns status of ChromaDB, employee store, LLM provider, and NeetoCal API key.

---

## API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/recommend` | Full pipeline: recommendation + employee match |
| POST | `/api/schedule` | Create NeetoCal consultation booking |
| POST | `/api/org/employees` | Seed / upsert employee profiles (admin) |
| GET | `/api/org/match` | Semantic employee search |
| PATCH | `/api/org/employees/{id}/availability` | Toggle availability |
| GET | `/api/techs` | List all tech stacks and their status |
| GET | `/api/health` | System health check |
| GET | `/docs` | Interactive Swagger UI |

---

## LLM provider profiles

Switch profiles via the `ARCHITECTAI_PROFILE` env var:

| Profile | Router | Agents | Embeddings | Best for |
|---------|--------|--------|------------|---------|
| `groq_free` | Llama-3.1-8B (Groq) | Llama-3.3-70B (Groq) | nomic-embed-text (Ollama) | **Default — fast, free** |
| `academic_local` | Llama-3.1:8B (Ollama) | Llama-3.1:8B (Ollama) | nomic-embed-text (Ollama) | Fully offline, no API keys |
| `production` | GPT-4o-mini (OpenAI) | GPT-4o (OpenAI) | nomic-embed-text (Ollama) | Highest quality |

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| `GROQ_API_KEY not set` | Add it to `.env` |
| `Ollama unavailable` | Start with `ollama serve`; falls back to sentence-transformers automatically |
| `Employee store empty` | Run `python seed_employees.py` |
| `Booking failed — API key not set` | Add `NEETOCAL_API_KEY` to `.env` |
| `Collection not found for tech_id` | Copy your ChromaDB data to `./data/chromadb/` or run the scraper |
| Port 8000 already in use | `uvicorn api:app --port 8001` |

---

## Adding a new tech agent

1. Create `rag/tech_agents/mytech_agent.py`:

```python
from base_agent import BaseTechAgent
from registry import register_agent

@register_agent
class MyTechAgent(BaseTechAgent):
    TECH_ID            = "mytech"
    TECH_NAME          = "MyTech"
    EXPERT_PERSONA     = "You are a senior MyTech architect..."
    ARCHITECTURE_FOCUS = "Key patterns for MyTech..."
    STRENGTHS          = ["When MyTech excels..."]
    WEAKNESSES         = ["When to recommend against MyTech..."]
    ANTI_PATTERNS      = ["Common mistakes to flag..."]
```

2. Import it in `rag/tech_agents/__init__.py`:
```python
import mytech_agent  # noqa: F401
```

3. Add the tech stack config to `scraper/config/tech_registry.py`.

4. Scrape its documentation to populate the ChromaDB collection.

---

## Adding a new employee

Either call `POST /api/org/employees` with the employee dict, or add to `org/seed_data.py` and re-run `python seed_employees.py`.
