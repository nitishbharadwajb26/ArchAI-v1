#!/usr/bin/env python3
"""
Seed the employee knowledge base.
Run once before starting the server (or run again to refresh).

Usage:
    python seed_employees.py
    python seed_employees.py --custom path/to/employees.json
"""

import argparse
import json
import logging
import sys
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
logger = logging.getLogger(__name__)

_ROOT = Path(__file__).resolve().parent
for p in [str(_ROOT), str(_ROOT / "scraper")]:
    if p not in sys.path:
        sys.path.insert(0, p)

from org.employee_store import EmployeeStore, EmployeeProfile
from org.seed_data import DEFAULT_EMPLOYEES


def main():
    parser = argparse.ArgumentParser(description="Seed ArchAI-Enterprise employee store")
    parser.add_argument("--custom", type=str, help="Path to custom employees JSON file")
    parser.add_argument("--chroma-path", type=str,
                        default=str(_ROOT / "data" / "chromadb"),
                        help="ChromaDB persist directory")
    args = parser.parse_args()

    store = EmployeeStore(chroma_path=args.chroma_path)
    logger.info(f"Current employee count: {store.count()}")

    if args.custom:
        path = Path(args.custom)
        if not path.exists():
            logger.error(f"File not found: {path}")
            sys.exit(1)
        with open(path) as f:
            raw_list = json.load(f)
        profiles = [EmployeeProfile.from_dict(r) for r in raw_list]
        logger.info(f"Loaded {len(profiles)} profiles from {path}")
    else:
        profiles = DEFAULT_EMPLOYEES
        logger.info(f"Using {len(profiles)} default employee profiles")

    count = store.upsert(profiles)
    logger.info(f"✓ Seeded {count} employee profiles. Total in store: {store.count()}")


if __name__ == "__main__":
    main()
